# Hydra - Usage guide (local demo)

Prerequisites:
- Docker & docker-compose plugin installed
- optional: AWS CLI configured if you want to run remote CodeBuild demo

## Local demo (recommended for one-night lab)

1. Build and start the static site:
   ```bash
   ./utils/scripts/run_local_demo.sh
